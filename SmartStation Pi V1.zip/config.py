# ==============================================================================
# SİSTEM YAPILANDIRMA VE BAĞLANTI AYARLARI
# ==============================================================================

# Wi-Fi Bağlantı Bilgileri
WIFI_ADI = "SUPERONLINE_Wi-Fi_3886"
WIFI_SIFRESI = "DRPRbYNEsQUk"

# Coğrafi Konum ve API Ayarları
SEHIR = "Izmir"
API_KEY = "cff69c0dd777fa73518805a72bd697ce"

# Zaman Dilimi Ayarı (Türkiye için UTC+3)
SAAT_DILIMI = 3

# Varsayılan Alarm Ayarları
VARSAYILAN_ALARM_SAAT = 7
VARSAYILAN_ALARM_DAKIKA = 30