import machine
import utime
import network
import ntptime
import dht
import urequests
import ustruct
import gc
import math
import ujson  # Kalıcı bellek dosya yönetimi için eklenen kütüphane
import config  # Yapılandırma parametrelerini içeri aktarır

# ==============================================================================
# 1. GEOMETRİK ÇİZİM DESTEKLİ DONANIMSAL EKRAN SÜRÜCÜSÜ (DARK MODE)
# ==============================================================================
class DirectST7789:
    def __init__(self, spi, reset, cs, dc, backlight):
        self.spi = spi
        self.reset = reset
        self.cs = cs
        self.dc = dc
        self.backlight = backlight
        self.width = 320
        self.height = 240

    def write_cmd(self, cmd):
        self.dc.value(0)
        self.cs.value(0)
        self.spi.write(bytearray([cmd]))
        self.cs.value(1)

    def write_data(self, data):
        self.dc.value(1)
        self.cs.value(0)
        self.spi.write(data)
        self.cs.value(1)

    def init(self):
        self.backlight.value(1)
        self.reset.value(1)
        utime.sleep_ms(10)
        self.reset.value(0)
        utime.sleep_ms(20)
        self.reset.value(1)
        utime.sleep_ms(120)

        self.write_cmd(0x01) # SWRESET
        utime.sleep_ms(150)
        self.write_cmd(0x11) # SLPOUT
        utime.sleep_ms(130)
        self.write_cmd(0x3A) # COLMOD
        self.write_data(bytearray([0x55]))
        self.write_cmd(0x36) # MADCTL
        self.write_data(bytearray([0x70])) # Landscape orientation
        self.write_cmd(0x21) # INVON (Ters renk düzeltmesi)
        self.write_cmd(0x29) # DISPON
        utime.sleep_ms(100)

    def set_window(self, x0, y0, x1, y1):
        self.write_cmd(0x2A) # CASET
        self.write_data(ustruct.pack(">HH", x0, x1))
        self.write_cmd(0x2B) # RASET
        self.write_data(ustruct.pack(">HH", y0, y1))
        self.write_cmd(0x2C) # RAMWR

    def clear(self, color):
        self.set_window(0, 0, self.width - 1, self.height - 1)
        hi, lo = color >> 8, color & 0xFF
        buf = bytearray([hi, lo] * 320)
        self.dc.value(1)
        self.cs.value(0)
        for _ in range(self.height):
            self.spi.write(buf)
        self.cs.value(1)

    def fill_rect(self, x, y, w, h, color):
        if x < 0 or y < 0 or x + w > self.width or y + h > self.height: return
        self.set_window(x, y, x + w - 1, y + h - 1)
        hi, lo = color >> 8, color & 0xFF
        buf = bytearray([hi, lo] * w)
        self.dc.value(1)
        self.cs.value(0)
        for _ in range(h):
            self.spi.write(buf)
        self.cs.value(1)

    def hline(self, x, y, w, color):
        if x < 0 or x >= self.width or y < 0 or y >= self.height: return
        if x + w > self.width: w = self.width - x
        self.set_window(x, y, x + w - 1, y)
        hi, lo = color >> 8, color & 0xFF
        buf = bytearray([hi, lo] * w)
        self.dc.value(1)
        self.cs.value(0)
        self.spi.write(buf)
        self.cs.value(1)

    def vline(self, x, y, h, color):
        if x < 0 or x >= self.width or y < 0 or y >= self.height: return
        if y + h > self.height: h = self.height - y
        self.set_window(x, y, x, y + h - 1)
        hi, lo = color >> 8, color & 0xFF
        buf = bytearray([hi, lo] * h)
        self.dc.value(1)
        self.cs.value(0)
        self.spi.write(buf)
        self.cs.value(1)

    def line(self, x0, y0, x1, y1, color):
        dx = abs(x1 - x0)
        dy = abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx - dy
        while True:
            self.hline(x0, y0, 1, color)
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                x0 += sx
            if e2 < dx:
                err += dx
                y0 += sy

    def circle(self, x0, y0, r, color):
        x = r
        y = 0
        err = 0
        while x >= y:
            self.hline(x0 + x, y0 + y, 1, color)
            self.hline(x0 + y, y0 + x, 1, color)
            self.hline(x0 - y, y0 + x, 1, color)
            self.hline(x0 - x, y0 + y, 1, color)
            self.hline(x0 - x, y0 - y, 1, color)
            self.hline(x0 - y, y0 - x, 1, color)
            self.hline(x0 + y, y0 - x, 1, color)
            self.hline(x0 + x, y0 - y, 1, color)
            y += 1
            if err <= 0:
                err += 2*y + 1
            if err > 0:
                x -= 1
                err -= 2*x + 1

# ==============================================================================
# 2. RENK TANIMLAMALARI VE DONANIMSAL GİRİŞ/ÇIKIŞ YAPILANDIRMASI
# ==============================================================================
spi = machine.SPI(1, baudrate=40000000, sck=machine.Pin(10), mosi=machine.Pin(11))
display = DirectST7789(
    spi, 
    reset=machine.Pin(12, machine.Pin.OUT), 
    cs=machine.Pin(9, machine.Pin.OUT), 
    dc=machine.Pin(8, machine.Pin.OUT), 
    backlight=machine.Pin(13, machine.Pin.OUT)
)
display.init()

# Canlı Renk Kodları (RGB565)
DARK_BG = 0x0842       
GOLD = 0xFEA0          
WHITE = 0xFFFF         
BLACK = 0x0000         
GRAY = 0x7BEF          
RED = 0xF800           
NEON_GREEN = 0x07E0    
AQUA = 0x07FF          
ORANGE = 0xFD20        

display.clear(DARK_BG)

# Sensör, Buzzer ve Buton Tanımlamaları
dht_sensor = dht.DHT11(machine.Pin(22))
buzzer = machine.PWM(machine.Pin(28))

# Güvenli Köşedeki Butonlar (GP2 ve GP3 - Dahili pull-up aktif)
btn_1 = machine.Pin(2, machine.Pin.IN, machine.Pin.PULL_UP)  # Sol Buton (GP2)
btn_2 = machine.Pin(3, machine.Pin.IN, machine.Pin.PULL_UP)  # Sağ Buton (GP3)

# Yapılandırma Dosyasından (config.py) Değişken Eşleşmeleri
WIFI_ADI = config.WIFI_ADI
WIFI_SIFRESI = config.WIFI_SIFRESI
SAAT_DILIMI = config.SAAT_DILIMI
API_KEY = config.API_KEY
SEHIR = config.SEHIR

# Ses Seviyesi (0-5) -> PWM Duty Cycle (0-32768) Eşleşme Tablosu
SES_DUTY_MAP = {
    0: 0,       # MUTE (Sessiz)
    1: 500,     # Çok Kısık
    2: 2000,    # Kısık
    3: 8000,    # Orta
    4: 16000,   # Yüksek
    5: 32768    # Maksimum (Kare Dalga %50)
}

# Değişkenlerin İlk Tanımlamaları (Kalıcı Bellekten Yüklenecektir)
ALARM_SAAT = config.VARSAYILAN_ALARM_SAAT
ALARM_DAKIKA = config.VARSAYILAN_ALARM_DAKIKA
alarm_aktif = True
alarm_susturuldu = False
alarm_caliyor = False
ses_seviyesi = getattr(config, "VARSAYILAN_SES_SEVIYESI", 3)

ekran_modu = 0  
anlik_dis_sicaklik = "--"
anlik_hava_metni = "OFFLINE MODE"
gunluk_tahminler = [] 
son_api_guncelleme = 0

GUNLER = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"]

# Karakter Veritabanı (FONT 5X7 - NOKTA DAHİL)
FONT_5X7 = {
    '0': (0x3e, 0x51, 0x49, 0x45, 0x3e), '1': (0x00, 0x42, 0x7f, 0x40, 0x00),
    '2': (0x42, 0x61, 0x51, 0x49, 0x46), '3': (0x22, 0x41, 0x49, 0x49, 0x36),
    '4': (0x18, 0x14, 0x12, 0x7f, 0x10), '5': (0x27, 0x45, 0x45, 0x45, 0x39),
    '6': (0x3c, 0x4a, 0x49, 0x49, 0x30), '7': (0x01, 0x71, 0x09, 0x05, 0x03),
    '8': (0x36, 0x49, 0x49, 0x49, 0x36), '9': (0x06, 0x49, 0x49, 0x29, 0x1e),
    ':': (0x00, 0x36, 0x36, 0x00, 0x00), '/': (0x20, 0x10, 0x08, 0x04, 0x02),
    ' ': (0x00, 0x00, 0x00, 0x00, 0x00), '-': (0x08, 0x08, 0x08, 0x08, 0x08),
    '[': (0x00, 0x7f, 0x41, 0x41, 0x00), ']': (0x00, 0x41, 0x41, 0x7f, 0x00),
    '|': (0x00, 0x00, 0x7f, 0x00, 0x00), '%': (0x23, 0x13, 0x08, 0x64, 0x62),
    '.': (0x00, 0x00, 0x60, 0x00, 0x00),
    'A': (0x7c, 0x12, 0x11, 0x12, 0x7c), 'B': (0x7f, 0x49, 0x49, 0x49, 0x36),
    'C': (0x3e, 0x41, 0x41, 0x41, 0x22), 'D': (0x7f, 0x41, 0x41, 0x22, 0x1c),
    'E': (0x7f, 0x49, 0x49, 0x49, 0x41), 'F': (0x7f, 0x09, 0x09, 0x09, 0x01),
    'G': (0x3e, 0x41, 0x49, 0x49, 0x7a), 'H': (0x7f, 0x08, 0x08, 0x08, 0x7f),
    'I': (0x00, 0x41, 0x7f, 0x41, 0x00), 'J': (0x20, 0x40, 0x41, 0x3f, 0x01),
    'K': (0x7f, 0x08, 0x14, 0x22, 0x41), 'L': (0x7f, 0x40, 0x40, 0x40, 0x40),
    'M': (0x7f, 0x02, 0x0c, 0x02, 0x7f), 'N': (0x7f, 0x04, 0x08, 0x10, 0x7f),
    'O': (0x3e, 0x41, 0x41, 0x41, 0x3e), 'P': (0x7f, 0x09, 0x09, 0x09, 0x06),
    'Q': (0x3e, 0x41, 0x51, 0x21, 0x5e), 'R': (0x7f, 0x09, 0x19, 0x29, 0x46),
    'S': (0x46, 0x49, 0x49, 0x49, 0x31), 'T': (0x01, 0x01, 0x7f, 0x01, 0x01),
    'U': (0x3f, 0x40, 0x40, 0x40, 0x3f), 'V': (0x1f, 0x20, 0x40, 0x20, 0x1f),
    'W': (0x3f, 0x40, 0x38, 0x40, 0x3f), 'X': (0x63, 0x14, 0x08, 0x14, 0x63),
    'Y': (0x07, 0x08, 0x70, 0x08, 0x07), 'Z': (0x61, 0x51, 0x49, 0x45, 0x43)
}

def ozel_metin_ciz(metin, x_start, y_start, renk=WHITE, boyut=2):
    for char in metin:
        if char in FONT_5X7:
            bitmap = FONT_5X7[char]
            for col in range(5):
                byte = bitmap[col]
                for row in range(7):
                    if byte & (1 << row):
                        px = x_start + col * boyut
                        py = y_start + row * boyut
                        display.hline(px, py, boyut, renk)
        x_start += 6 * boyut

def ekrana_yaz_ortala(metin, y, renk=WHITE, boyut=2):
    metin_uzunlugu = len(metin) * (6 * boyut)
    x_merkez = (320 - metin_uzunlugu) // 2
    if x_merkez < 0: x_merkez = 0
    ozel_metin_ciz(metin, x_merkez, y, renk, boyut)

def hava_rengi_al(metin):
    m = metin.upper()
    if "SUN" in m or "CLEAR" in m: return GOLD
    if "RAIN" in m or "DRIZ" in m or "SHOWER" in m: return AQUA
    if "SNOW" in m: return WHITE
    if "CLOU" in m or "MIST" in m or "HAZE" in m or "FOG" in m: return GRAY
    return WHITE

# Volüm Ayarlı Buzzer Fonksiyonu
def buzzer_ses(frekans, sure):
    global ses_seviyesi
    if frekans == 0 or ses_seviyesi == 0: 
        buzzer.duty_u16(0)
    else:
        buzzer.freq(frekans)
        buzzer.duty_u16(SES_DUTY_MAP.get(ses_seviyesi, 8000))
    utime.sleep(sure)
    buzzer.duty_u16(0)

# ==============================================================================
# SİSTEM VERİ KAYIT VE YÜKLEME SİSTEMİ (PERSISTENCE)
# ==============================================================================
def verileri_kaydet():
    global ALARM_SAAT, ALARM_DAKIKA, alarm_aktif, ses_seviyesi
    dosya_adi = "alarm_data.json"
    data = {
        "alarm_saat": ALARM_SAAT,
        "alarm_dakika": ALARM_DAKIKA,
        "alarm_aktif": alarm_aktif,
        "ses_seviyesi": ses_seviyesi
    }
    try:
        with open(dosya_adi, "w") as f:
            ujson.dump(data, f)
        print("Ayarlar basariyla kaydirildi.")
    except Exception as e:
        print("Ayarlar kaydedilirken hata olustu:", e)

def verileri_yukle():
    global ALARM_SAAT, ALARM_DAKIKA, alarm_aktif, ses_seviyesi
    dosya_adi = "alarm_data.json"
    try:
        with open(dosya_adi, "r") as f:
            data = ujson.load(f)
            ALARM_SAAT = data.get("alarm_saat", config.VARSAYILAN_ALARM_SAAT)
            ALARM_DAKIKA = data.get("alarm_dakika", config.VARSAYILAN_ALARM_DAKIKA)
            alarm_aktif = data.get("alarm_aktif", True)
            ses_seviyesi = data.get("ses_seviyesi", 3)
        print("Ayarlar basariyla yuklendi.")
    except Exception as e:
        print("Ayar dosyasi bulunamadi, varsayilanlar yukleniyor.")
        ALARM_SAAT = config.VARSAYILAN_ALARM_SAAT
        ALARM_DAKIKA = config.VARSAYILAN_ALARM_DAKIKA
        alarm_aktif = True
        ses_seviyesi = 3

# Kalıcı bellekten verileri yükle
verileri_yukle()

# ==============================================================================
# GÜVENLİ ZAMAN SENKRONİZASYONU VE BELLEK KORUMALARI
# ==============================================================================
def zaman_senkronize_et():
    try:
        ntptime.host = "time.google.com"
        ntptime.settime() 
        yerel_saniye = utime.time() + (SAAT_DILIMI * 3600)
        tm = utime.localtime(yerel_saniye)
        rtc.datetime((tm[0], tm[1], tm[2], tm[6], tm[3], tm[4], tm[5], 0))
        return True
    except Exception as e:
        print("NTP Hatası, timeapi.io deneniyor...", e)
        
    try:
        res = urequests.get("http://timeapi.io/api/Time/current/zone?timeZone=Europe/Istanbul", timeout=5)
        if res.status_code == 200:
            data = res.json()
            rtc.datetime((data["year"], data["month"], data["day"], 0, data["hour"], data["minute"], data["seconds"], 0))
            res.close()
            return True
        res.close()
    except Exception as e:
        print("timeapi.io Hatası, worldtimeapi deneniyor...", e)

    try:
        res = urequests.get("http://worldtimeapi.org/api/timezone/Europe/Istanbul", timeout=5)
        if res.status_code == 200:
            data = res.json()
            unixtime = data["unixtime"]
            raw_offset = data["raw_offset"]
            res.close()
            yerel_saniye = unixtime + raw_offset - 946684800
            tm = utime.localtime(yerel_saniye)
            rtc.datetime((tm[0], tm[1], tm[2], tm[6], tm[3], tm[4], tm[5], 0))
            return True
        res.close()
    except Exception as e:
        print("worldtimeapi Hatası:", e)
        
    return False

def hava_verilerini_cek():
    global anlik_dis_sicaklik, anlik_hava_metni, gunluk_tahminler
    gc.collect()
    
    # 1. Anlık Hava Durumu
    try:
        url_current = f"http://api.openweathermap.org/data/2.5/weather?q={SEHIR}&appid={API_KEY}&units=metric&lang=en"
        res = urequests.get(url_current, timeout=5)
        
        if res.status_code == 200:
            data_current = res.json()
            anlik_dis_sicaklik = int(data_current["main"]["temp"])
            anlik_hava_metni = data_current["weather"][0]["description"].upper()
            del data_current  
        elif res.status_code == 401:
            anlik_hava_metni = "INVALID API KEY"
        else:
            anlik_hava_metni = f"ERROR {res.status_code}"
        res.close()
    except Exception as e:
        print("Anlik Hava Durumu Hatası:", e)
        anlik_hava_metni = "API TIMEOUT"
        
    gc.collect()
    
    # 2. 5 Günlük Hava Tahmini
    try:
        url_forecast = f"http://api.openweathermap.org/data/2.5/forecast?q={SEHIR}&appid={API_KEY}&units=metric"
        res = urequests.get(url_forecast, timeout=5)
        
        if res.status_code == 200:
            data_forecast = res.json()
            temp_forecasts = []
            forecast_list = data_forecast.get("list", [])
            for i in range(0, min(len(forecast_list), 40), 8):
                g_veri = forecast_list[i]
                temp = int(g_veri["main"]["temp"])
                durum = g_veri["weather"][0]["main"][:4].upper()
                temp_forecasts.append({"temp": temp, "durum": durum})
            
            gunluk_tahminler = temp_forecasts
            del data_forecast  
        else:
            gunluk_tahminler = []
        res.close()
    except Exception as e:
        print("Tahmin API Hatası:", e)
        if not gunluk_tahminler:
            gunluk_tahminler = []
    finally:
        gc.collect()

# --- Boot / Wi-Fi Bağlantı Yönetimi ---
# Üst Kısımdaki Logo ve İmza Sabittir
ekrana_yaz_ortala("SMARTSTATION PI", 50, GOLD, boyut=2)
ekrana_yaz_ortala("DEVELOPED BY HTEKIN.COM", 100, WHITE, boyut=2)
# Dinamik Bağlantı Durumu
ekrana_yaz_ortala("CONNECTING WI-FI...", 170, AQUA, boyut=1)

wlan = network.WLAN(network.STA_IF)
wlan.active(True)
wlan.connect(WIFI_ADI, WIFI_SIFRESI)

sayac = 0
while not wlan.isconnected() and sayac < 20:
    utime.sleep(0.5)
    sayac += 1

display.clear(DARK_BG)
rtc = machine.RTC()

if wlan.isconnected():
    ekrana_yaz_ortala("SMARTSTATION PI", 50, GOLD, boyut=2)
    ekrana_yaz_ortala("DEVELOPED BY HTEKIN.COM", 100, WHITE, boyut=2)
    ekrana_yaz_ortala("WI-FI CONNECTED", 170, NEON_GREEN, boyut=1)
    utime.sleep(2.5) 
    
    zaman_durumu = zaman_senkronize_et()
    
    if zaman_durumu:
        hava_verilerini_cek()
        son_api_guncelleme = utime.time()
        buzzer_ses(523, 0.1)
    else:
        display.clear(DARK_BG)
        ekrana_yaz_ortala("SMARTSTATION PI", 50, GOLD, boyut=2)
        ekrana_yaz_ortala("DEVELOPED BY HTEKIN.COM", 100, WHITE, boyut=2)
        ekrana_yaz_ortala("SYNC ERROR", 170, RED, boyut=1)
        utime.sleep(1.5)
else:
    ekrana_yaz_ortala("SMARTSTATION PI", 50, GOLD, boyut=2)
    ekrana_yaz_ortala("DEVELOPED BY HTEKIN.COM", 100, WHITE, boyut=2)
    ekrana_yaz_ortala("OFFLINE MODE", 170, RED, boyut=1)
    rtc.datetime((2026, 7, 7, 1, 12, 0, 0, 0))
    utime.sleep(1.5)

# Bekçi Köpeği (Watchdog) Başlatma
try:
    wdt = machine.WDT(timeout=8000) 
except Exception as e:
    print("Watchdog baslatilamadi:", e)
    wdt = None

# Durum Takip Değişkenleri
eski_saniye = -1
eski_dakika = -1
eski_ekran_modu = -1
eski_ic_sicaklik = None
eski_ic_nem = None
eski_anlik_dis_sicaklik = None

eski_alarm_saat = -1
eski_alarm_dakika = -1
eski_alarm_aktif = None
eski_ses_seviyesi = -1

ic_sicaklik, ic_nem = "--", "--"
son_dht_okuma = 0

# Kırpışmasız Analog İbre Belleği (Y0 = 102 Hizalama Değerleri ile Güncellendi)
prev_sx, prev_sy = 160, 57
prev_mx, prev_my = 160, 64
prev_hx, prev_hy = 160, 77

# Buton Okuma ve Ticks Değişkenleri
btn_1_pressed_at = 0
btn_2_pressed_at = 0
btn_2_long_triggered = False

display.clear(DARK_BG)

# ==============================================================================
# 4. KESİNTİSİZ BUTON TETİKLEYİCİLERİ (NON-BLOCKING BUTTON HANDLERS)
# ==============================================================================
def trigger_btn_1_short():
    global ekran_modu, ALARM_SAAT, ALARM_DAKIKA, alarm_aktif, alarm_susturuldu, alarm_caliyor, ses_seviyesi
    if alarm_caliyor and not alarm_susturuldu:
        alarm_susturuldu = True
        buzzer_ses(440, 0.1) 
    else:
        if ekran_modu == 0:
            ekran_modu = 1
            buzzer_ses(554, 0.05)
        elif ekran_modu == 1:
            ekran_modu = 0
            buzzer_ses(554, 0.05)
        elif ekran_modu == 2:
            ALARM_SAAT = (ALARM_SAAT + 1) % 24
            buzzer_ses(700, 0.05)
        elif ekran_modu == 3:
            ALARM_DAKIKA = (ALARM_DAKIKA + 5) % 60
            buzzer_ses(700, 0.05)
        elif ekran_modu == 4:
            alarm_aktif = not alarm_aktif
            buzzer_ses(600 if alarm_aktif else 300, 0.05)
        elif ekran_modu == 5:
            # 0'dan 5'e döngüsel ses artırımı
            ses_seviyesi = (ses_seviyesi + 1) % 6
            buzzer_ses(600, 0.05)

def trigger_btn_2_short():
    global ekran_modu, alarm_aktif, alarm_susturuldu, alarm_caliyor
    if alarm_caliyor and not alarm_susturuldu:
        alarm_susturuldu = True
        buzzer_ses(440, 0.1) 
    else:
        if ekran_modu == 0:
            alarm_aktif = not alarm_aktif
            verileri_kaydet() # Ana menüden hızlı aç/kapa yapıldığında kaydeder
            buzzer_ses(600 if alarm_aktif else 300, 0.05)
        elif ekran_modu == 1:
            ekran_modu = 0
            buzzer_ses(554, 0.05)
        elif ekran_modu == 2:
            ekran_modu = 3
            buzzer_ses(554, 0.05)
        elif ekran_modu == 3:
            ekran_modu = 4
            buzzer_ses(554, 0.05)
        elif ekran_modu == 4:
            # Alarm durumu onaylandıktan sonra Ses Seviyesi (Mod 5) sayfasına geçilir
            ekran_modu = 5
            buzzer_ses(554, 0.05)
        elif ekran_modu == 5:
            # Ses seviyesi onaylandıktan sonra veriler kalıcı flash belleğe yazılır ve çıkılır
            verileri_kaydet()
            ekran_modu = 0
            buzzer_ses(880, 0.1)

def trigger_btn_2_long():
    global ekran_modu
    if ekran_modu == 0:
        ekran_modu = 2
        buzzer_ses(440, 0.3)

# ==============================================================================
# 5. ANA RUNTIME DÖNGÜSÜ (HATA YAKALAMA VE GERİ KAZANIM KORUMALI)
# ==============================================================================
while True:
    try:
        if wdt:
            wdt.feed() # Bekçi köpeği besleniyor

        yil, ay, gun, wd, saat, dakika, saniye, yearday = rtc.datetime()
        
        # 30 Dakikada bir dış hava durumunu güncelle
        if wlan.isconnected() and (utime.time() - son_api_guncelleme > 1800):
            hava_verilerini_cek()
            son_api_guncelleme = utime.time()

        # DHT11'i 5 saniyede bir oku
        simdi = utime.time()
        if simdi - son_dht_okuma > 5:
            try:
                dht_sensor.measure()
                ic_sicaklik = dht_sensor.temperature()
                ic_nem = dht_sensor.humidity()
            except:
                ic_sicaklik, ic_nem = "--", "--"
            son_dht_okuma = simdi

        # Ekran modu değişti mi kontrolü
        mod_degisti = (ekran_modu != eski_ekran_modu)
        if mod_degisti:
            display.clear(DARK_BG)
            eski_ekran_modu = ekran_modu
            eski_saniye = -1
            eski_dakika = -1
            eski_ic_sicaklik = None
            eski_ic_nem = None
            eski_anlik_dis_sicaklik = None
            eski_alarm_saat = -1
            eski_alarm_dakika = -1
            eski_alarm_aktif = None
            eski_ses_seviyesi = -1

        # --- SAYFA 0: ANA MENÜ (HİZALANMIŞ ANALOG SAAT TASARIMI) ---
        if ekran_modu == 0:
            if mod_degisti:
                display.hline(10, 38, 300, GRAY)
                display.hline(10, 165, 300, GRAY)
                
                # Kadran Çizimi (Merkez x=160, y=102, R=50) -> Y0=102 ile Ortalandı
                display.circle(160, 102, 50, GOLD)
                
                # Saat Tıklama Noktaları (Y0=102 referansıyla dikey dikey olarak ortalandı)
                display.fill_rect(159, 53, 3, 3, GOLD)  # 12
                display.fill_rect(207, 101, 3, 3, GOLD) # 3
                display.fill_rect(159, 149, 3, 3, GOLD) # 6
                display.fill_rect(110, 101, 3, 3, GOLD) # 9
                
                prev_sx, prev_sy = 160, 57
                prev_mx, prev_my = 160, 64
                prev_hx, prev_hy = 160, 77

            # 1. Tarih Alanı
            if dakika != eski_dakika or mod_degisti:
                display.fill_rect(10, 12, 300, 20, DARK_BG)
                date_str = f"{GUNLER[wd]}, {gun:02d}-{ay:02d}-{yil}"
                ekrana_yaz_ortala(date_str, 15, AQUA, boyut=2)

            # 2. Pürüzsüz Akan İbreler (Sıfır Kırpışma - 102 Koordinat Merkezli)
            if saniye != eski_saniye:
                display.line(160, 102, prev_hx, prev_hy, DARK_BG)
                display.line(160, 102, prev_mx, prev_my, DARK_BG)
                display.line(160, 102, prev_sx, prev_sy, DARK_BG)
                
                # Saat Göbeği
                display.fill_rect(158, 100, 5, 5, GOLD)

                sec_angle = saniye * 6 * math.pi / 180
                min_angle = dakika * 6 * math.pi / 180
                hour_angle = (saat % 12 + dakika / 60) * 30 * math.pi / 180

                sx = int(160 + 45 * math.sin(sec_angle))
                sy = int(102 - 45 * math.cos(sec_angle))
                mx = int(160 + 38 * math.sin(min_angle))
                my = int(102 - 38 * math.cos(min_angle))
                hx = int(160 + 25 * math.sin(hour_angle))
                hy = int(102 - 25 * math.cos(hour_angle))

                # Yeni İbrelerin Çizilmesi
                display.line(160, 102, hx, hy, WHITE)
                display.line(161, 102, hx+1, hy, WHITE)
                display.line(160, 102, mx, my, GRAY)
                display.line(160, 102, sx, sy, RED)

                # Kadran İçi Dijital Saat Sub-Dial Alanı 
                display.fill_rect(130, 114, 60, 10, DARK_BG)
                ekrana_yaz_ortala(f"{saat:02d}:{dakika:02d}", 115, GOLD, boyut=1)

                prev_sx, prev_sy = sx, sy
                prev_mx, prev_my = mx, my
                prev_hx, prev_hy = hx, hy

                eski_saniye = saniye

            # 3. İÇ ORTAM ALANI
            if ic_sicaklik != eski_ic_sicaklik or ic_nem != eski_ic_nem or mod_degisti:
                display.fill_rect(10, 170, 300, 22, DARK_BG)
                
                temp_text = f"IN:{ic_sicaklik}C"
                sep_text = " | "
                hum_text = f"HUM:%{ic_nem}"
                total_len = len(temp_text) + len(sep_text) + len(hum_text)
                x_start = 160 - (total_len * 12) // 2
                
                ozel_metin_ciz(temp_text, x_start, 172, ORANGE, 2)
                x_start += len(temp_text) * 12
                ozel_metin_ciz(sep_text, x_start, 172, WHITE, 2)
                x_start += len(sep_text) * 12
                ozel_metin_ciz(hum_text, x_start, 172, AQUA, 2)

                eski_ic_sicaklik = ic_sicaklik
                eski_ic_nem = ic_nem

            # 4. DIŞ ORTAM ALANI
            if anlik_dis_sicaklik != eski_anlik_dis_sicaklik or mod_degisti:
                display.fill_rect(10, 195, 300, 22, DARK_BG)
                weather_color = hava_rengi_al(anlik_hava_metni)
                full_out_str = f"{SEHIR.upper()}:{anlik_dis_sicaklik}C | {anlik_hava_metni}"
                ekrana_yaz_ortala(full_out_str, 198, weather_color, boyut=2)
                eski_anlik_dis_sicaklik = anlik_dis_sicaklik

            # 5. ALARM DURUMU
            if ALARM_SAAT != eski_alarm_saat or ALARM_DAKIKA != eski_alarm_dakika or alarm_aktif != eski_alarm_aktif or mod_degisti:
                display.fill_rect(10, 220, 300, 18, DARK_BG)
                status_str = "ON" if alarm_aktif else "OFF"
                status_color = NEON_GREEN if alarm_aktif else RED
                
                alarm_str = f"ALARM: {ALARM_SAAT:02d}:{ALARM_DAKIKA:02d} "
                total_len = len(alarm_str) + len(status_str) + 2
                x_start = 160 - (total_len * 6) // 2
                
                ozel_metin_ciz(alarm_str, x_start, 224, WHITE, 1)
                ozel_metin_ciz(f"[{status_str}]", x_start + (len(alarm_str) * 6), 224, status_color, 1)

                eski_alarm_saat = ALARM_SAAT
                eski_alarm_dakika = ALARM_DAKIKA
                eski_alarm_aktif = alarm_aktif

            eski_dakika = dakika

        # --- SAYFA 1: TAHMİN MENÜSÜ ---
        elif ekran_modu == 1:
            if mod_degisti:
                ekrana_yaz_ortala(f"{SEHIR.upper()} FORECAST", 10, GOLD, boyut=2)
                display.hline(10, 35, 300, WHITE)
                
                if len(gunluk_tahminler) >= 5:
                    for i, tahmin in enumerate(gunluk_tahminler[:5]):
                        sutun_baslangic_x = i * 64
                        
                        gun_metni = GUNLER[(wd + i) % 7]
                        x_gun = sutun_baslangic_x + (64 - len(gun_metni) * 6) // 2
                        ozel_metin_ciz(gun_metni, x_gun, 50, AQUA, 1)
                        
                        durum_metni = tahmin["durum"][:4].upper()
                        x_durum = sutun_baslangic_x + (64 - len(durum_metni) * 6) // 2
                        ozel_metin_ciz(durum_metni, x_durum, 95, hava_rengi_al(durum_metni), 1)
                        
                        sicaklik_metni = f"{tahmin['temp']}C"
                        x_sicaklik = sutun_baslangic_x + (64 - len(sicaklik_metni) * 6) // 2
                        ozel_metin_ciz(sicaklik_metni, x_sicaklik, 140, WHITE, 1)
                        
                        if i > 0:
                            display.vline(sutun_baslangic_x, 35, 160, GRAY)
                else:
                    ekrana_yaz_ortala("NO FORECAST DATA", 100, WHITE, boyut=2)
                    
                display.hline(10, 195, 300, WHITE)
                ekrana_yaz_ortala("[B1/B2] BACK TO MAIN MENU", 210, WHITE, boyut=1)

        # --- SAYFA 2: ALARM SAAT AYARI ---
        elif ekran_modu == 2:
            if ALARM_SAAT != eski_alarm_saat or mod_degisti:
                display.fill_rect(10, 10, 300, 220, DARK_BG)
                ekrana_yaz_ortala("SET ALARM: HOUR", 20, GOLD, boyut=2)
                ekrana_yaz_ortala(f"[{ALARM_SAAT:02d}] : {ALARM_DAKIKA:02d}", 90, ORANGE, boyut=5)
                ekrana_yaz_ortala("[B1] INCREASE | [B2] NEXT", 190, WHITE, boyut=1)
                eski_alarm_saat = ALARM_SAAT

        # --- SAYFA 3: ALARM DAKİKA AYARI ---
        elif ekran_modu == 3:
            if ALARM_DAKIKA != eski_alarm_dakika or mod_degisti:
                display.fill_rect(10, 10, 300, 220, DARK_BG)
                ekrana_yaz_ortala("SET ALARM: MINUTE", 20, GOLD, boyut=2)
                ekrana_yaz_ortala(f"{ALARM_SAAT:02d} : [{ALARM_DAKIKA:02d}]", 90, AQUA, boyut=5)
                ekrana_yaz_ortala("[B1] INCREASE | [B2] NEXT", 190, WHITE, boyut=1)
                eski_alarm_dakika = ALARM_DAKIKA

        # --- SAYFA 4: ALARM DURUM AYARI ---
        elif ekran_modu == 4:
            if alarm_aktif != eski_alarm_aktif or mod_degisti:
                display.fill_rect(10, 10, 300, 220, DARK_BG)
                ekrana_yaz_ortala("SET ALARM: STATE", 20, GOLD, boyut=2)
                
                durum_metni = "ON" if alarm_aktif else "OFF"
                state_color = NEON_GREEN if alarm_aktif else RED
                
                ekrana_yaz_ortala(f"STATE: [{durum_metni}]", 90, state_color, boyut=4)
                ekrana_yaz_ortala("[B1] TOGGLE | [B2] NEXT", 190, WHITE, boyut=1)
                eski_alarm_aktif = alarm_aktif

        # --- SAYFA 5: SİSTEM SES SEVİYESİ AYARI (VOLUME) ---
        elif ekran_modu == 5:
            if ses_seviyesi != eski_ses_seviyesi or mod_degisti:
                display.fill_rect(10, 10, 300, 220, DARK_BG)
                ekrana_yaz_ortala("SET SYSTEM VOLUME", 20, GOLD, boyut=2)
                
                level_str = "MUTE" if ses_seviyesi == 0 else f"LEVEL: {ses_seviyesi}"
                ekrana_yaz_ortala(level_str, 80, ORANGE, boyut=4)
                
                # Ses Barı Grafiği (Dinamik Görsel Seviye)
                bar_x = 60
                bar_y = 140
                bar_w = 200
                bar_h = 20
                display.fill_rect(bar_x, bar_y, bar_w, bar_h, GRAY)
                
                if ses_seviyesi > 0:
                    display.fill_rect(bar_x, bar_y, ses_seviyesi * 40, bar_h, NEON_GREEN)
                
                ekrana_yaz_ortala("[B1] CHANGE | [B2] SAVE & EXIT", 190, WHITE, boyut=1)
                eski_ses_seviyesi = ses_seviyesi

        # ==============================================================================
        # ALARM ÇALMA VE HATA ÖNLEYİCİ KİLİT YÖNETİMİ
        # ==============================================================================
        simdi_dakika = saat * 60 + dakika
        alarm_dakika_toplam = ALARM_SAAT * 60 + ALARM_DAKIKA
        fark_dakika = (simdi_dakika - alarm_dakika_toplam) % 1440
        
        # Alarm 5 dakika boyunca aktif kabul edilir
        alarm_caliyor = False
        if alarm_aktif and fark_dakika < 5:
            alarm_caliyor = True
            
        # Alarm çalma penceresi dışındaysak yazılımsal susturma kilidini bir sonraki güne sıfırla
        if not alarm_caliyor:
            alarm_susturuldu = False

        # Eğer alarm süresi içindeysek ve butona basılıp susturulmadıysa öttür
        if alarm_caliyor and not alarm_susturuldu:
            buzzer_ses(880, 0.1)
            utime.sleep_ms(50)

        # ==============================================================================
        # 6. ASENKRON (BLOKLAMAYAN) BUTON SORGULAMA MOTORU
        # ==============================================================================
        now_ms = utime.ticks_ms()

        # SOL BUTON (GP2) - Kısa Basış Algılama
        b1_val = btn_1.value()
        if b1_val == 0:
            if btn_1_pressed_at == 0:
                btn_1_pressed_at = now_ms
        else:
            if btn_1_pressed_at != 0:
                press_duration = utime.ticks_diff(now_ms, btn_1_pressed_at)
                btn_1_pressed_at = 0
                if press_duration > 50:  # Gürültü (Debounce) filtresi
                    trigger_btn_1_short()

        # SAĞ BUTON (GP3) - Kısa / 2 Saniye Uzun Basış Algılama
        b2_val = btn_2.value()
        if b2_val == 0:
            if btn_2_pressed_at == 0:
                btn_2_pressed_at = now_ms
            elif not btn_2_long_triggered and utime.ticks_diff(now_ms, btn_2_pressed_at) >= 2000:
                trigger_btn_2_long()
                btn_2_long_triggered = True
        else:
            if btn_2_pressed_at != 0:
                press_duration = utime.ticks_diff(now_ms, btn_2_pressed_at)
                btn_2_pressed_at = 0
                if not btn_2_long_triggered and press_duration > 50:
                    trigger_btn_2_short()
                btn_2_long_triggered = False

        eski_saniye = saniye
        eski_dakika = dakika

        utime.sleep_ms(20) # 50 Hz Buton Tarama Frekansı

    except Exception as e:
        # ==========================================================================
        # YAZILIMSAL ÇÖKME DURUMUNDA DIAGNOSTIC VE RESET PANELİ
        # ==========================================================================
        machine.Pin(13, machine.Pin.OUT).value(1)
        display.clear(0xF800)
        
        ekrana_yaz_ortala("SOFTWARE ERROR", 40, WHITE, boyut=2)
        
        err_msg = str(e).upper()
        if len(err_msg) == 0:
            err_msg = "UNKNOWN ERROR"
            
        ekrana_yaz_ortala(err_msg[:25], 100, WHITE, boyut=2)
        if len(err_msg) > 25:
            ekrana_yaz_ortala(err_msg[25:50], 135, WHITE, boyut=1)
            
        ekrana_yaz_ortala("REBOOTING SYSTEM...", 190, WHITE, boyut=2)
        
        # WDT aktifse sistemi 8 saniye içinde resetler, yoksa sonsuz döngüde bekler
        while True:
            utime.sleep(1)